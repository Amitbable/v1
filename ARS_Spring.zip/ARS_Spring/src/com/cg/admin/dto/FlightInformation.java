package com.cg.admin.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="flightinformation")
public class FlightInformation 
{
	@Id
	@SequenceGenerator(name="flight_no_seq", sequenceName="f_no_seq", allocationSize=2)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="flight_no_seq")
	private int flightNo;

	@Column(name="airline")
	private String airline;

	@Column(name="source")
	private String deptCity;

	@Column(name="destination")
	private String arrCity;

	@Column(name="departuredate")
	private String deptDate;

	@Column(name="arrivaldate")
	private String arrDate;

	@Column(name="departuretime")
	private String deptTime;

	@Column(name="arrivaltime")
	private String arrTime;

	private int firstSeats;
	private double firstSeatsFare;

	private int bussSeats;
	private double bussSeatsFare;

	@Column(name="firstSeatsAvail")
	private int avlFirstSeats;

	@Column(name="bussSeatsAvail")
	private int avlBussSeats;
	
	public FlightInformation() 
	{
		super();
		
	}
	@Override
	public String toString() {
		return "FlightInformation [flightNo=" + flightNo + ", airline="
				+ airline + ", deptCity=" + deptCity + ", arrCity=" + arrCity
				+ ", deptDate=" + deptDate + ", arrDate=" + arrDate
				+ ", deptTime=" + deptTime + ", arrTime=" + arrTime
				+ ", firstSeats=" + firstSeats + ", firstSeatsFare="
				+ firstSeatsFare + ", bussSeats=" + bussSeats
				+ ", bussSeatsFare=" + bussSeatsFare + ", avlFirstSeats="
				+ avlFirstSeats + ", avlBussSeats=" + avlBussSeats + "]";
	}
	
	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDeptCity() {
		return deptCity;
	}
	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDeptDate() {
		return deptDate;
	}
	public void setDeptDate(String deptDate) {
		this.deptDate = deptDate;
	}
	public String getArrDate() {
		return arrDate;
	}
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}
	public String getDeptTime() {
		return deptTime;
	}
	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public double getFirstSeatsFare() {
		return firstSeatsFare;
	}
	public void setFirstSeatsFare(double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public double getBussSeatsFare() {
		return bussSeatsFare;
	}
	public void setBussSeatsFare(double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}
	public int getAvlFirstSeats() {
		return avlFirstSeats;
	}
	public void setAvlFirstSeats(int avlFirstSeats) {
		this.avlFirstSeats = avlFirstSeats;
	}
	public int getAvlBussSeats() {
		return avlBussSeats;
	}
	public void setAvlBussSeats(int avlBussSeats) {
		this.avlBussSeats = avlBussSeats;
	}
	public FlightInformation(int flightNo, String airline, String deptCity,
			String arrCity, String deptDate, String arrDate,
			String deptTime, String arrTime, int firstSeats,
			double firstSeatsFare, int bussSeats, double bussSeatsFare,
			int avlFirstSeats, int avlBussSeats) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.deptCity = deptCity;
		this.arrCity = arrCity;
		this.deptDate = deptDate;
		this.arrDate = arrDate;
		this.deptTime = deptTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.bussSeats = bussSeats;
		this.bussSeatsFare = bussSeatsFare;
		this.avlFirstSeats = avlFirstSeats;
		this.avlBussSeats = avlBussSeats;
	}
	
	public FlightInformation(int flightNo, String airline, String deptCity,
			String arrCity,  String deptTime) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.deptCity = deptCity;
		this.arrCity = arrCity;
		this.deptTime = deptTime;
		
	}
	

	
	public FlightInformation(int flightNo, String airline, String deptCity,
			String arrCity, String deptDate, String deptTime,
			int firstSeats,int avlFirstSeats,int bussSeats,int avlBussSeats) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.deptCity = deptCity;
		this.arrCity = arrCity;
		this.deptDate = deptDate;
		
		this.deptTime = deptTime;
		
		this.firstSeats = firstSeats;
		this.avlFirstSeats=avlFirstSeats;
		this.bussSeats = bussSeats;
		this.avlBussSeats=avlBussSeats;
	
	}
	public FlightInformation(int flightNo, String airline, String deptCity,
			String arrCity, String deptDate, String arrDate,
			String deptTime, String arrTime, int firstSeats,
			double firstSeatsFare, int bussSeats, double bussSeatsFare) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.deptCity = deptCity;
		this.arrCity = arrCity;
		this.deptDate = deptDate;
		this.arrDate = arrDate;
		this.deptTime = deptTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.bussSeats = bussSeats;
		this.bussSeatsFare = bussSeatsFare;
	}
	public boolean bookFirstSeats(int fSeats)
	{
		if(avlFirstSeats>=fSeats)
		{
			avlFirstSeats=avlFirstSeats-fSeats;
			return true;
		}
		else return false;
		
	}
	
	public boolean bookBussSeats(int bSeats)
	{
		if(avlBussSeats>=bSeats)
		{
			avlBussSeats=avlBussSeats-bSeats;
			return true;
		}
		else return false;
		
	}
	
	public boolean cancelFirstSeats(int fSeats)
	{
		if(fSeats<avlFirstSeats)
		{
			avlFirstSeats=avlFirstSeats+fSeats;
			return true;
		}
		else return false;
		
	}
	public boolean cancelBussSeats(int bSeats)
	{
		if(bSeats<avlBussSeats)
		{
			avlBussSeats=avlBussSeats+bSeats;
			return true;
		}
		else return false;
		
	}
}
